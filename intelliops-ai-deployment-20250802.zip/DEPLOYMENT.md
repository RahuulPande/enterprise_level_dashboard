# IntelliOps AI - Deployment Instructions

## Quick Start

1. **Install Dependencies:**
   ```bash
   npm install
   ```

2. **Environment Setup:**
   ```bash
   cp .env.example .env.local
   # Edit .env.local with your configuration
   ```

3. **Development:**
   ```bash
   npm run dev
   ```

4. **Production Build:**
   ```bash
   npm run build
   npm start
   ```

## Live Demo
The application is already deployed at:
https://ai-ml-dashboard-pomomct98-rahuul-pandes-projects.vercel.app

## Features
- 20+ enterprise features
- AI-powered defect matching (96% accuracy)
- Real-time monitoring of 150+ services
- $16.7M annual savings demonstration

## Support
Developer: Rahuul Pande
Email: kumar.rahul@cognizant.com
Event: Vibe Coding 2025
