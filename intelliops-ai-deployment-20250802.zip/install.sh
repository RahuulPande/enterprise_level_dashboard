#!/bin/bash
echo "🚀 Installing IntelliOps AI..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is required. Please install Node.js 18+ first."
    exit 1
fi

# Check Node.js version
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js 18+ is required. Current version: $(node -v)"
    exit 1
fi

echo "✅ Node.js version: $(node -v)"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Copy environment file
if [ ! -f .env.local ]; then
    echo "📝 Setting up environment configuration..."
    cp .env.example .env.local
    echo "✅ Environment file created. Edit .env.local if needed."
fi

echo "🎉 Installation complete!"
echo "🚀 Run 'npm run dev' to start the development server"
echo "🌐 Visit http://localhost:3000 to view the application"
